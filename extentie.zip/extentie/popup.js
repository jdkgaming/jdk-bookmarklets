document.getElementById('bookmarkletForm').onsubmit = function() {
  var input1 = document.getElementById('input1').value;
  var input2 = document.getElementById('input2').value;
  var bgcol = document.getElementById('bg').value;

  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    var activeTab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: activeTab.id },
      func: changeIconAndTitle,
      args: [input1, input2, bgcol]
    });
  });

  return false;
};

document.getElementById('editoff').onclick = function() {
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    var activeTab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: activeTab.id },
      func: off
    });
  });
};

document.getElementById('editon').onclick = function() {
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    var activeTab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: activeTab.id },
      func: on
    });
  });
};



function changeIconAndTitle(iconUrl, pageTitle, bgcol) {
  var links = document.querySelectorAll("link[rel*='icon'], link[rel='apple-touch-icon']");
  if (links.length === 0) {
    var newLink = document.createElement('link');
    newLink.type = 'image/x-icon';
    newLink.rel = 'shortcut icon';
    newLink.href = iconUrl;
    document.getElementsByTagName('head')[0].appendChild(newLink);
    alert('Er waren geen icoons op deze pagina. Een nieuw icoon is toegevoegd.');
  } else {
    for (var i = 0; i < links.length; i++) {
      links[i].href = iconUrl;
    }
  }

  document.title = pageTitle;
  document.body.style.backgroundColor = bgcol;
  alert('De icoon is gewijzigd naar: ' + iconUrl + '\nDe paginatitel is gewijzigd naar: ' + pageTitle + '\nDe achtergrondkleur is gewijzigd naar: ' + bgcol);
}

function on() {
  document.body.contentEditable = true;
  alert('Je kan nu de inhoud van de pagina bewerken.');
}

function off() {
  document.body.contentEditable = false;
  alert('Je kan nu de inhoud van de pagina niet meer bewerken.');

}
